import React, {Component} from 'react';

class Movies extends Component {


  render() {
    return (
      <div>
        <h1>The lying baby</h1>
        <img src="img/fract13.png"></img>
      </div>

    );
  }
}

export default Movies;
